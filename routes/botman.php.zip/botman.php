<?php

use App\Http\Controllers\BotManController;
use BotMan\BotMan\BotMan;

/** @var BotMan $botman */
$botman = resolve('botman');

$botman->hears("telefon|danışman|çağrı", function(BotMan $bot) {
    $bot->reply("Çözüm Merkezi için aramanız gereken telefon numarası: <b><a href=\"tel:+904442864\">444 2 864</a></b>");
})->skipsConversation();

$botman->hears('merhaba', BotManController::class.'@startConversation');

$botman->fallback(function($bot) {
    $bot->reply('Konuşma başlatmak için <b>merhaba</b> yazabilirsiniz. Çözüm merkezimizle görüşmek istiyorsanız <b><a href="tel:+904442864">444 2 864</a></b> numaralı telefondan bize ulaşabilirsiniz.');
});